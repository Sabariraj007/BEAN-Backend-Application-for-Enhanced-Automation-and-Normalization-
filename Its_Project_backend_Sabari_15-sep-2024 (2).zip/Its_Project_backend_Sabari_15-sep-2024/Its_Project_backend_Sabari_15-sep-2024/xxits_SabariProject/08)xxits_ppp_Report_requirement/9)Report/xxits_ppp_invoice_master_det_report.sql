create or replace procedure xxits_ppp_invoice_master_det_report
as
    cursor invoice_cursor is 
        select 
            e.header_id as header_v,
            e.customer_name,
            e.contact_number,
            e.email,
            f.header_id as header_l,
            f.line_id,
            f.product_name,
            f.product_description,
            f.category_name,
            f.cart_id,
            f.gst,
            f.total_amount as line_total_amount, 
            f.payment_method,
            f.payment_status,
            f.vendor_name,
            f.total_amount as header_total_amount,
            f.order_date,
            f.order_status,
            f.quantity
        from 
            xxits_ppp_validated_header_t e, 
            xxits_ppp_validated_line_t f
        where 
            e.header_id = f.header_id(+);
begin
    dbms_output.put_line('<LIST_G_CUST_INVOICE_CODE>');
    for i in invoice_cursor loop
        dbms_output.put_line('<G_CUST_CODE>');
        dbms_output.put_line('<CUSTOMER_NAME>' || i.customer_name || '</CUSTOMER_NAME>');
        dbms_output.put_line('<CONTACT_NUMBER>' || i.contact_number || '</CONTACT_NUMBER>');
        dbms_output.put_line('<EMAIL>' || i.email || '</EMAIL>');
        dbms_output.put_line('<PRODUCT_NAME>' || i.product_name || '</PRODUCT_NAME>');
        dbms_output.put_line('<PRODUCT_DES>' || i.product_description || '</PRODUCT_DES>');
        dbms_output.put_line('<CATEGORY_NAME>' || i.category_name || '</CATEGORY_NAME>');
        dbms_output.put_line('<CART_ID>' || i.cart_id || '</CART_ID>');
        dbms_output.put_line('<GST>' || i.gst || '</GST>');
        dbms_output.put_line('<PAYMENT_METHOD>' || i.payment_method || '</PAYMENT_METHOD>');
        dbms_output.put_line('<PAYMENT_STATUS>' || i.payment_status || '</PAYMENT_STATUS>');
        dbms_output.put_line('<TOTAL_AMOUNT>' || i.line_total_amount || '</TOTAL_AMOUNT>'); 
        dbms_output.put_line('<ORDER_DATE>' || i.order_date || '</ORDER_DATE>'); 
        dbms_output.put_line('<ORDER_STATUS>' || i.order_status || '</ORDER_STATUS>'); 
        dbms_output.put_line('<QUANTITY>' || i.quantity || '</QUANTITY>');
    end loop;
    dbms_output.put_line('</LIST_G_CUST_INVOICE_CODE>');
exception
    when others then 
        dbms_output.put_line('Main exception --------->:' || sqlerrm);
end xxits_ppp_invoice_master_det_report;




begin
xxits_ppp_invoice_master_det_report();
end;


set serveroutput on;