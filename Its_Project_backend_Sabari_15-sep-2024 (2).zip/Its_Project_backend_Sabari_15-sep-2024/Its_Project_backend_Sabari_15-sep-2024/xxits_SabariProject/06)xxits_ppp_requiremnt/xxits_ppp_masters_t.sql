create or replace procedure xxits_ppp_masters_t
is
    cursor master_insert_cursor is
        select 
            c.header_id as c_header_id,
            c.customer_id,
            c.customer_name,
            c.email,
            c.contact_number,
            c.location,
            d.header_id as d_header_id,
            d.line_id,
            d.purchase_date,
            d.quantity,
            d.purchase_id,
            d.payment_id,
            d.payment_method,
            d.payment_status,
            d.cart_id,
            d.category_id,
            d.category_name,
            d.order_date,
            d.order_status,
            d.vendor_id,
            d.vendor_name,
            d.product_id,
            d.product_name,
            d.product_description,
            d.total_amount
        from 
            xxits_ppp_validated_header_t c  ,
            xxits_ppp_validated_line_t d
            where c.header_id = d.header_id;

begin
    execute immediate 'CREATE TABLE Xxits_Ppp_Customer_Master_T (' ||
                      'Header_Id NUMBER, ' ||
                      'Customer_Id NUMBER, ' ||
                      'Customer_Name VARCHAR2(400), ' ||
                      'Location VARCHAR2(400), ' ||
                      'Contact_Number NUMBER, ' ||
                      'Email VARCHAR2(400))';

    execute immediate 'CREATE TABLE Xxits_Ppp_Purchase_Master_T (' ||
                      'Purchase_Id NUMBER, ' ||
                      'Purchase_Date DATE, ' ||
                      'Total_Amount NUMBER)';

    execute immediate 'CREATE TABLE Xxits_Ppp_Product_Master_T (' ||
                      'Product_Id NUMBER, ' ||
                      'Product_Name VARCHAR2(240), ' ||
                      'Product_Description VARCHAR2(240))';

    execute immediate 'CREATE TABLE Xxits_Ppp_Vendor_Master_T (' ||
                      'Vendor_Id NUMBER, ' ||
                      'Vendor_Name VARCHAR2(240), ' ||
                      'Product_Description VARCHAR2(240))';

    execute immediate 'CREATE TABLE Xxits_Ppp_Payment_Master_T (' ||
                      'Payment_Id NUMBER, ' ||
                      'Payment_Method VARCHAR2(240), ' ||
                      'Payment_Status VARCHAR2(240))';

    execute immediate 'CREATE TABLE Xxits_Ppp_Category_Master_T (' ||
                      'Category_Id NUMBER, ' ||
                      'Category_Name VARCHAR2(240))';

    execute immediate 'CREATE TABLE Xxits_Ppp_Cart_Master_T (' ||
                      'Cart_Id NUMBER, ' ||
                      'Product_Id NUMBER, ' ||
                      'Quantity NUMBER)';

    for rec in master_insert_cursor loop
        execute immediate 'INSERT INTO Xxits_Ppp_Customer_Master_T (Header_Id, Customer_Id, Customer_Name, Location, Contact_Number, Email) ' ||
                          'VALUES (:1, :2, :3, :4, :5, :6)'
        using rec.c_header_id, rec.customer_id, rec.customer_name, rec.location, rec.contact_number, rec.email;

        execute immediate 'INSERT INTO Xxits_Ppp_Purchase_Master_T (Purchase_Id, Purchase_Date, Total_Amount) ' ||
                          'VALUES (:1, :2, :3)'
        using rec.purchase_id, rec.purchase_date, rec.total_amount;

        
        execute immediate 'INSERT INTO Xxits_Ppp_Product_Master_T (Product_Id, Product_Name, Product_Description) ' ||
                          'VALUES (:1, :2, :3)'
        using rec.product_id, rec.product_name, rec.product_description;

        
        execute immediate 'INSERT INTO Xxits_Ppp_Vendor_Master_T (Vendor_Id, Vendor_Name, Product_Description) ' ||
                          'VALUES (:1, :2, :3)'
        using rec.vendor_id, rec.vendor_name, rec.product_description;

        
        execute immediate 'INSERT INTO Xxits_Ppp_Payment_Master_T (Payment_Id, Payment_Method, Payment_Status) ' ||
                          'VALUES (:1, :2, :3)'
        using rec.payment_id, rec.payment_method, rec.payment_status;

        
        execute immediate 'INSERT INTO Xxits_Ppp_Category_Master_T (Category_Id, Category_Name) ' ||
                          'VALUES (:1, :2)'
        using rec.category_id, rec.category_name;

        
        execute immediate 'INSERT INTO Xxits_Ppp_Cart_Master_T (Cart_Id, Product_Id, Quantity) ' ||
                          'VALUES (:1, :2, :3)'
        using rec.cart_id, rec.product_id, rec.quantity;
    end loop;
end xxits_ppp_masters_t;

begin
xxits_ppp_masters_t();
end;


