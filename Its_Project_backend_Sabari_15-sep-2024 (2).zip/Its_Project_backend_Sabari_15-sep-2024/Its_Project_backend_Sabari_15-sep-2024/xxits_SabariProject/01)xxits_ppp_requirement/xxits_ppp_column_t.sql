
create table xxits_ppp_column_t (
    column_name        varchar2(4000),
    data_type          varchar2(4000),
    table_name         varchar2(4000),
    attribute_category varchar2(4000)
);