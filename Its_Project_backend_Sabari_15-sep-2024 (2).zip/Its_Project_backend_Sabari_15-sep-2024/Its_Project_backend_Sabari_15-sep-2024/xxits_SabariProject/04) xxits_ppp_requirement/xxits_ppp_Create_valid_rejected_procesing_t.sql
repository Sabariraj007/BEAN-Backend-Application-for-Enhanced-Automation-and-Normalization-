create or replace procedure xxits_ppp_insert_vrp_data_proc as
    l_sql varchar2(4000);
    l_columns_header varchar2(4000) := '';
    l_columns_line varchar2(4000) := '';
begin
    -- Accumulate column definitions for `header` and `line` tables
    for rec in (select column_name, data_type, table_name from xxits_ppp_column_t order by table_name) loop
        if rec.table_name = 'header' then
            l_columns_header := l_columns_header || rec.column_name || ' ' || rec.data_type || ', ';
        elsif rec.table_name = 'line' then
            l_columns_line := l_columns_line || rec.column_name || ' ' || rec.data_type || ', ';
        end if;
    end loop;

    -- Remove trailing commas and spaces
    l_columns_header := rtrim(l_columns_header, ', ');
    l_columns_line := rtrim(l_columns_line, ', ');

    -- Create validated, rejected, and processing tables for `header` data
    l_sql := 'CREATE TABLE xxits_ppp_validated_header_t (' || l_columns_header || ')';
    execute immediate l_sql;

    l_sql := 'CREATE TABLE xxits_ppp_rejected_header_t (' || l_columns_header || ')';
    execute immediate l_sql;

    l_sql := 'CREATE TABLE xxits_ppp_processing_header_t (' || l_columns_header || ')';
    execute immediate l_sql;

    -- Create validated, rejected, and processing tables for `line` data
    l_sql := 'CREATE TABLE xxits_ppp_validated_line_t (' || l_columns_line || ')';
    execute immediate l_sql;

    l_sql := 'CREATE TABLE xxits_ppp_rejected_line_t (' || l_columns_line || ')';
    execute immediate l_sql;

    l_sql := 'CREATE TABLE xxits_ppp_processing_line_t (' || l_columns_line || ')';
    execute immediate l_sql;
end xxits_ppp_insert_vrp_data_proc;
/

-- Run the procedure
BEGIN
    xxits_ppp_insert_vrp_data_proc();
END;
/




BEGIN
    xxits_ppp_insert_vrp_data_proc();
END;
/