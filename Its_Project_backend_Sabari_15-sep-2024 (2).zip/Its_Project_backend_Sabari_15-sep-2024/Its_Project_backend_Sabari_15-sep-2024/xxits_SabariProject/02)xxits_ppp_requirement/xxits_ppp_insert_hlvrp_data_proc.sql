create or replace procedure xxits_ppp_create_tables_proc as
    l_sql varchar2(4000);
    l_current_table varchar2(50);
    l_columns_added varchar2(4000);  
begin
    for rec in (select table_name, column_name, data_type 
                from xxits_ppp_column_t 
                where table_name in ('header', 'line')
                order by table_name, column_name) 
    loop
        
        if l_current_table is null or l_current_table != rec.table_name then
            if l_sql is not null then
               
                l_sql := l_sql || ')';
                execute immediate l_sql;
            end if;
            
            l_sql := 'CREATE TABLE xxits_ppp_' || rec.table_name || '_t (' || rec.column_name || ' ' || rec.data_type;
            l_columns_added := rec.column_name;  
            l_current_table := rec.table_name;
        else
            if instr(l_columns_added, rec.column_name) = 0 then
                l_sql := l_sql || ', ' || rec.column_name || ' ' || rec.data_type;
                l_columns_added := l_columns_added || ',' || rec.column_name;  
            end if;
        end if;
    end loop;

   
    if l_sql is not null then
        l_sql := l_sql || ')';
        execute immediate l_sql;
    end if;
end;

begin
xxits_ppp_create_tables_proc();
end;
