CREATE OR REPLACE DIRECTORY MINI_PROJECT12 AS 'D:\Its_Project_backend_15-sep-2024';
/
create or replace procedure xxits_pms_xml_proc(P_ERROR_COLUMN  in  varchar2)
as
    cursor  customer(P_CUSTOMER_ID in number)is
    select  CUSTOMER_ID ,CUSTOMER_NAME,CONTACT_NUMBER,EMAIL,LOCATION,ERROR_COLUMN
    from    system.xxits_ppp_validated_header_t
    where  CUSTOMER_ID   =  P_CUSTOMER_ID;
    cursor product is        
    select  distinct LINE_ID,PRODUCT_ID,PRODUCT_NAME,ORDER_DATE,CATEGORY_NAME,GST,CART_ID,VENDOR_NAME,PAYMENT_METHOD,PAYMENT_STATUS,QUANTITY,UNIT_PRICE,TOTAL_AMOUNT
        from    system.xxits_ppp_validated_line_t;
    lc_file_handle UTL_FILE.FILE_TYPE;    
    lc_file_name     varchar2(500)   := 'ITS'||'_'||P_ERROR_COLUMN||'BEAN'||TO_DATE(SYSDATE,'DD-MM-YY')||000||XXITS_CAP_SEQ.nextval||'.XML'; 
    lc_directory     varchar2(300)   :='MINI_PROJECT12';
    
begin
    lc_file_handle := UTL_FILE.FOPEN(lc_directory, lc_file_name, 'W');
   
    UTL_FILE.PUT_LINE(lc_file_handle, '<?xml version="1.0" encoding="UTF-8"?>');  
                          UTL_FILE.PUT_LINE(lc_file_handle,'<LIST_S_CUSTOMER_CODE>');
    for J in customer(1)
    loop
                    UTL_FILE.put_line(lc_file_handle,'<G_CUSTOMER_CODE>');          
      UTL_FILE.put_line  (lc_file_handle,'<CUSTOMER_ID>'         ||j.CUSTOMER_ID          || '</CUSTOMER_ID> ');
      UTL_FILE.put_line  (lc_file_handle,'<CUSTOMER_NAME>'       ||j.CUSTOMER_NAME        || '</CUSTOMER_NAME>');
      UTL_FILE.put_line  (lc_file_handle,'<CONTACT_NUMBER>'      ||j.CONTACT_NUMBER       || '</CONTACT_NUMBER>');
      UTL_FILE.put_line  (lc_file_handle,'<EMAIL>'               ||j.EMAIL                || '</EMAIL>');
                    UTL_FILE.put_line   (lc_file_handle,'</G_CUSTOMER_CODE>');
                    UTL_FILE.put_line   (lc_file_handle,'<LIST_S_ITEM_CODE>');  
           for i in product
           loop
                          UTL_FILE.put_line   (lc_file_handle,'<G_CUSTOMER_CODE>');
--          UTL_FILE.put_line  (lc_file_handle,'<LINE_ID> '        ||j.CUSTOMER_ID            || '</LINE_ID>');                
        UTL_FILE.put_line  (lc_file_handle,'<LINE_ID> '        ||i.LINE_ID            || '</LINE_ID>');
      UTL_FILE.put_line  (lc_file_handle,'<PRODUCT_NAME>'    ||i.PRODUCT_NAME        || '</PRODUCT_NAME>');
      UTL_FILE.put_line  (lc_file_handle,'<VENDOR_NAME>'    ||i.VENDOR_NAME        || '</VENDOR_NAME>');
      UTL_FILE.put_line  (lc_file_handle,'<CART_ID>'   ||i.CART_ID || '</CART_ID>');
      UTL_FILE.put_line  (lc_file_handle,'<CATEGORY_NAME>'    ||i.CATEGORY_NAME    || '</CATEGORY_NAME>');
      UTL_FILE.put_line  (lc_file_handle,'<PAYMENT_METHOD>'    ||i.PAYMENT_METHOD    || '</PAYMENT_METHOD>');
      UTL_FILE.put_line  (lc_file_handle,'<PAYMENT_STATUS>' ||i.PAYMENT_STATUS ||    '</PAYMENT_STATUS>');
      UTL_FILE.put_line  (lc_file_handle,'<ORDER_DATE>' ||i.ORDER_DATE        ||    '</ORDER_DATE>');
      UTL_FILE.put_line  (lc_file_handle,'<QUANTITY>' ||i.QUANTITY        ||    '</QUANTITY>');
      UTL_FILE.put_line  (lc_file_handle,'<UNIT_PRICE>' ||i.UNIT_PRICE        ||    '</UNIT_PRICE>');
      UTL_FILE.put_line  (lc_file_handle,'<AMOUNT>' ||i.TOTAL_AMOUNT            ||    '</AMOUNT>');
      UTL_FILE.put_line  (lc_file_handle,'<GST_V>' ||i.GST            ||    '</GST_V>');
                          UTL_FILE.put_line   (lc_file_handle,'</G_CUSTOMER_CODE>');
      end  loop;
                 UTL_FILE.put_line   (lc_file_handle,'</LIST_S_ITEM_CODE>');
      end   loop;
                   UTL_FILE.put_line   (lc_file_handle,'</LIST_S_CUSTOMER_CODE>');
     UTL_FILE.FCLOSE(lc_file_handle);              
exception
    when  others    then
    dbms_output.put_line(sqlerrm);              
end xxits_pms_xml_proc;

/
 CREATE SEQUENCE XXITS_CAP_SEQ
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;


set serveroutput on;

    begin
    xxits_pms_xml_proc('V');
    end;