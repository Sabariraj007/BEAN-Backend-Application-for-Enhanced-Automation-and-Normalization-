create or replace package XXITS_PPP_FVALIDATION_PKG as
    
    function VALIDATE_DUPLICATE(P_TABLE_NAME in varchar2, P_COLUMN_NAME in varchar2, P_VALUE in varchar2) return boolean;

   
    function VALIDATE_EMAIL(P_EMAIL in varchar2) return boolean;

    function CALCULATE_EXPIRY_DAYS(P_EXPIRY_DATE in date) return number;

    procedure GET_USER_INFO(P_USER_ID in number, P_USER_NAME out varchar2);

    function GET_TODAY return date;

    procedure LOG_DELETION(P_TABLE_NAME in varchar2, P_RECORD_ID in number);
end XXITS_PPP_FVALIDATION_PKG;
/



create or replace package body XXITS_PPP_FVALIDATION_PKG as

    function VALIDATE_DUPLICATE(P_TABLE_NAME in varchar2, P_COLUMN_NAME in varchar2, P_VALUE in varchar2) return boolean is
        V_COUNT number;
    begin
        execute immediate 'SELECT COUNT(1) FROM ' || P_TABLE_NAME || ' WHERE ' || P_COLUMN_NAME || ' = :1' into V_COUNT using P_VALUE;
        return V_COUNT > 0;
    end VALIDATE_DUPLICATE;

    function VALIDATE_EMAIL(P_EMAIL in varchar2) return boolean is
    begin
        return regexp_like(P_EMAIL, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');
    end VALIDATE_EMAIL;

    function CALCULATE_EXPIRY_DAYS(P_EXPIRY_DATE in date) return number is
    begin
        return P_EXPIRY_DATE - SYSDATE;
    end CALCULATE_EXPIRY_DAYS;

    procedure GET_USER_INFO(P_USER_ID in number, P_USER_NAME out varchar2) is
    begin
        select USER_NAME into P_USER_NAME from USER_TABLE where USER_ID = P_USER_ID;
    exception
        when NO_DATA_FOUND then
            P_USER_NAME := 'Unknown';
    end GET_USER_INFO;

    function GET_TODAY return date is
    begin
        return SYSDATE;
    end GET_TODAY;

    procedure LOG_DELETION(P_TABLE_NAME in varchar2, P_RECORD_ID in number) is
        V_QUERY varchar2(32767);
    begin
        V_QUERY := 'INSERT INTO deleted_records_' || P_TABLE_NAME || 
                   ' SELECT * FROM ' || P_TABLE_NAME || ' WHERE id = :1';
        execute immediate V_QUERY using P_RECORD_ID;

        V_QUERY := 'DELETE FROM ' || P_TABLE_NAME || ' WHERE id = :1';
        execute immediate V_QUERY using P_RECORD_ID;
    end LOG_DELETION;

end XXITS_PPP_FVALIDATION_PKG;
/




create or replace trigger TRG_LOG_DELETION
after delete on YOUR_TABLE_NAME
for each row
begin
    XXITS_PPP_FVALIDATION_PKG.LOG_DELETION('your_table_name', :old.id);
end;
/
