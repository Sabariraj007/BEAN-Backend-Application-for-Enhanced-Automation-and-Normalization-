CREATE OR REPLACE PACKAGE BODY XXITS_PPP_FVALIDATIONS_PKG AS

    FUNCTION VALIDATE_DUPLICATE(P_TABLE_NAME IN VARCHAR2, P_COLUMN_NAME IN VARCHAR2, P_VALUE IN VARCHAR2) RETURN BOOLEAN IS
        V_COUNT NUMBER;
    BEGIN
        EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_TABLE_NAME || ' WHERE ' || P_COLUMN_NAME || ' = :1' INTO V_COUNT USING P_VALUE;
        RETURN V_COUNT > 0;
    END VALIDATE_DUPLICATE;

--    FUNCTION VALIDATE_EMAIL(P_EMAIL IN VARCHAR2) RETURN BOOLEAN IS
--    BEGIN
--        RETURN REGEXP_LIKE(P_EMAIL, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');
--    END VALIDATE_EMAIL;
--
----    FUNCTION CALCULATE_EXPIRY_DAYS(P_EXPIRY_DATE IN DATE) RETURN NUMBER IS
----    BEGIN
----        RETURN P_EXPIRY_DATE - SYSDATE;
----    END CALCULATE_EXPIRY_DAYS;
--
--    PROCEDURE GET_USER_INFO(P_USER_ID IN NUMBER, P_USER_NAME OUT VARCHAR2) IS
--    BEGIN
--        EXECUTE IMMEDIATE '
--        BEGIN
--            EXECUTE IMMEDIATE ''CREATE TABLE xxits_ppp_users_t(
--                user_id             NUMBER,
--                user_name           VARCHAR2(240),
--                creation_date       DATE DEFAULT TO_DATE(''15-sep-2023'', ''DD-MON-YYYY''),
--                creation_by         VARCHAR2(400) DEFAULT ''sabari rajan'',
--                last_update_by      VARCHAR2(400),
--                last_update_login   VARCHAR2(400)
--            )'';
--        EXCEPTION
--            WHEN OTHERS THEN
--                IF SQLCODE != -955 THEN RAISE; END IF; -- Ignore "table already exists" error
--        END;';
--
--        
--        BEGIN
--            INSERT INTO xxits_ppp_users_t (user_id, user_name) VALUES (1, 'saravanan');
--            INSERT INTO xxits_ppp_users_t (user_id, user_name) VALUES (2, 'eramkumar');
--        EXCEPTION
--            WHEN DUP_VAL_ON_INDEX THEN NULL; 
--        END;
--
--        SELECT user_name INTO P_USER_NAME FROM xxits_ppp_users_t WHERE user_id = P_USER_ID;
--    EXCEPTION
--        WHEN NO_DATA_FOUND THEN
--            P_USER_NAME := 'Unknown';
--    END GET_USER_INFO;
--
--    PROCEDURE XXITS_PPP_USERS_PROC (
--        P_USER_ID          IN NUMBER,
--        P_USER_NAME        IN VARCHAR2,
--        P_LAST_UPDATE_BY   VARCHAR2,
--        P_LAST_UPDATE_DATE DATE
--    ) IS
--    BEGIN
--        UPDATE xxits_ppp_users_t
--        SET last_update_date     = P_LAST_UPDATE_DATE,
--            last_update_by       = P_LAST_UPDATE_BY,
--            last_update_login    = USER
--        WHERE user_id = P_USER_ID;
--    EXCEPTION
--        WHEN OTHERS THEN
--            DBMS_OUTPUT.PUT_LINE(SQLERRM);
--    END XXITS_PPP_USERS_PROC;
--
--    FUNCTION GET_TODAY RETURN DATE IS
--    BEGIN
--        RETURN SYSDATE;
--    END GET_TODAY;
--
END XXITS_PPP_FVALIDATIONS_PKG;
/
