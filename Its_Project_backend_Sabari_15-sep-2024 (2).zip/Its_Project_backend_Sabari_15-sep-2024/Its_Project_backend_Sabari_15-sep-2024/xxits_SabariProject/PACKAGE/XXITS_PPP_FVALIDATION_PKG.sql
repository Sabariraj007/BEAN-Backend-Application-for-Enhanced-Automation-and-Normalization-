create or replace package XXITS_PPP_FVALIDATIONS_PKG as

    function VALIDATE_DUPLICATE(P_TABLE_NAME in varchar2, P_COLUMN_NAME in varchar2, P_VALUE in varchar2) return boolean;
--
--    function VALIDATE_EMAIL(P_EMAIL in varchar2) return boolean;
--
----    function CALCULATE_EXPIRY_DAYS(P_EXPIRY_DATE in date) return number;
--
--    procedure GET_USER_INFO(P_USER_ID in number, P_USER_NAME out varchar2);
--
--    function GET_TODAY return date;
--
--    procedure LOG_DELETION(P_TABLE_NAME in varchar2, P_RECORD_ID in number);
--
end XXITS_PPP_FVALIDATIONS_PKG;
/

