CREATE OR REPLACE PROCEDURE xxits_ppp_validate_line_data_proc (
    new_phone IN VARCHAR2,
    new_email IN VARCHAR2
) AS
    duplicate_contact NUMBER := 0;
    duplicate_email NUMBER := 0;
BEGIN


    
    FOR rec_1 IN (SELECT h.header_id, h.customer_id, h.customer_name, h.contact_number, h.email, h.location, 
                          i.purchase_date, i.line_id, i.vendor_name, i.payment_method, i.total_amount, 
                          i.unit_price, i.gst, i.quantity, i.product_description, i.order_date, 
                          i.product_name, i.category_name, i.product_id, i.cart_id, i.category_id, 
                          i.purchase_id, i.order_status, i.payment_status, i.payment_id, 
                          i.vendor_id, i.reference_number, 
                          h.header_id AS header_id_h, i.header_id AS header_id_i 
                   FROM xxits_ppp_header_t h, xxits_ppp_line_t i 
                   WHERE h.header_id = i.header_id) LOOP

        -- Validate order_date (MM-DD-YYYY format)
        IF rec_1.order_date IS NULL OR NOT regexp_like(TO_CHAR(rec_1.order_date, 'MM-DD-YYYY'), '^\d{2}-\d{2}-\d{4}$') THEN
            INSERT INTO xxits_ppp_rejected_line_t (line_id, vendor_name, payment_method, total_amount, unit_price, gst, 
                                                    quantity, product_description, order_date, product_name, category_name, 
                                                    product_id, cart_id, category_id, purchase_id, order_status, 
                                                    payment_status, payment_id, vendor_id, reference_number, 
                                                    header_id, error_column, error_msg)
            VALUES (rec_1.line_id, rec_1.vendor_name, rec_1.payment_method, rec_1.total_amount, rec_1.unit_price, rec_1.gst,
                    rec_1.quantity, rec_1.product_description, rec_1.order_date, rec_1.product_name, rec_1.category_name, 
                    rec_1.product_id, rec_1.cart_id, rec_1.category_id, rec_1.purchase_id, rec_1.order_status, 
                    rec_1.payment_status, rec_1.payment_id, rec_1.vendor_id, rec_1.reference_number, rec_1.header_id, 
                    'E', 'Order Date Format Should Be MM-DD-YYYY.');
        END IF;

        -- Validate payment_method and payment_status
        IF (rec_1.payment_method = 'Cash' AND rec_1.payment_status = 'Unpaid') OR
           (rec_1.payment_method = 'Paytm' AND rec_1.payment_status = 'Unpaid') THEN
            INSERT INTO xxits_ppp_processing_line_t (line_id, vendor_name, payment_method, total_amount, unit_price, gst, 
                                                     quantity, product_description, order_date, product_name, category_name, 
                                                     product_id, cart_id, category_id, purchase_id, order_status, 
                                                     payment_status, payment_id, vendor_id, reference_number, 
                                                     header_id, error_column, error_msg)
            VALUES (rec_1.line_id, rec_1.vendor_name, rec_1.payment_method, rec_1.total_amount, rec_1.unit_price, rec_1.gst,
                    rec_1.quantity, rec_1.product_description, rec_1.order_date, rec_1.product_name, rec_1.category_name, 
                    rec_1.product_id, rec_1.cart_id, rec_1.category_id, rec_1.purchase_id, rec_1.order_status, 
                    rec_1.payment_status, rec_1.payment_id, rec_1.vendor_id, rec_1.reference_number, rec_1.header_id, 
                    'E', 'Unpaid Payment Detected.');
        ELSE
            INSERT INTO xxits_ppp_validated_line_t (line_id, vendor_name, payment_method, total_amount, unit_price, gst, 
                                                    quantity, product_description, order_date, product_name, category_name, 
                                                    product_id, cart_id, category_id, purchase_id, order_status, 
                                                    payment_status, payment_id, vendor_id, reference_number, 
                                                    header_id, error_column, error_msg)
            VALUES (rec_1.line_id, rec_1.vendor_name, rec_1.payment_method, rec_1.total_amount, rec_1.unit_price, rec_1.gst,
                    rec_1.quantity, rec_1.product_description, rec_1.order_date, rec_1.product_name, rec_1.category_name, 
                    rec_1.product_id, rec_1.cart_id, rec_1.category_id, rec_1.purchase_id, rec_1.order_status, 
                    rec_1.payment_status, rec_1.payment_id, rec_1.vendor_id, rec_1.reference_number, rec_1.header_id, 
                    'V', 'Valid');
        END IF;
    END LOOP;

    -- Revalidate and move rejected line data to validated line
    FOR rec_3 IN (SELECT * FROM xxits_ppp_rejected_line_t) LOOP
        BEGIN
            CASE
                WHEN rec_3.error_msg = 'Order Date Format Should Be MM-DD-YYYY.' THEN
                    UPDATE xxits_ppp_line_t
                    SET order_date = TO_DATE(new_phone, 'MM-DD-YYYY'), error_column = 'V', error_msg = 'Valid'
                    WHERE line_id = rec_3.line_id;
                    INSERT INTO xxits_ppp_validated_line_t (line_id, vendor_name, payment_method, total_amount, unit_price, gst, 
                                                            quantity, product_description, order_date, product_name, category_name, 
                                                            product_id, cart_id, category_id, purchase_id, order_status, 
                                                            payment_status, payment_id, vendor_id, reference_number, 
                                                            header_id, error_column, error_msg)
                    VALUES (rec_3.line_id, rec_3.vendor_name, rec_3.payment_method, rec_3.total_amount, rec_3.unit_price, rec_3.gst,
                            rec_3.quantity, rec_3.product_description, rec_3.order_date, rec_3.product_name, rec_3.category_name, 
                            rec_3.product_id, rec_3.cart_id, rec_3.category_id, rec_3.purchase_id, rec_3.order_status, 
                            rec_3.payment_status, rec_3.payment_id, rec_3.vendor_id, rec_3.reference_number, rec_3.header_id, 
                            'V', 'Valid');
                ELSE
                    NULL;
            END CASE;
        END;

        -- Optionally, delete rejected line data if you no longer need it
        -- DELETE FROM xxits_ppp_rejected_line_t WHERE line_id = rec_3.line_id;
    END LOOP;

    -- Revalidate and move processing line data to validated line
    FOR rec_4 IN (SELECT * FROM xxits_ppp_processing_line_t) LOOP
        BEGIN
            CASE
                WHEN rec_4.error_msg = 'Unpaid Payment Detected.' THEN
                    UPDATE xxits_ppp_line_t
                    SET payment_status = 'Paid', error_column = 'V', error_msg = 'Valid'
                    WHERE line_id = rec_4.line_id;
                    INSERT INTO xxits_ppp_validated_line_t (line_id, vendor_name, payment_method, total_amount, unit_price, gst, 
                                                            quantity, product_description, order_date, product_name, category_name, 
                                                            product_id, cart_id, category_id, purchase_id, order_status, 
                                                            payment_status, payment_id, vendor_id, reference_number, 
                                                            header_id, error_column, error_msg)
                    VALUES (rec_4.line_id, rec_4.vendor_name, rec_4.payment_method, rec_4.total_amount, rec_4.unit_price, rec_4.gst,
                            rec_4.quantity, rec_4.product_description, rec_4.order_date, rec_4.product_name, rec_4.category_name, 
                            rec_4.product_id, rec_4.cart_id, rec_4.category_id, rec_4.purchase_id, rec_4.order_status, 
                            rec_4.payment_status, rec_4.payment_id, rec_4.vendor_id, rec_4.reference_number, rec_4.header_id, 
                            'V', 'Valid');
                ELSE
                    NULL;
            END CASE;
        END;

        -- Optionally, delete processing line data if you no longer need it
        -- DELETE FROM xxits_ppp_processing_line_t WHERE line_id = rec_4.line_id;
    END LOOP;

END xxits_ppp_validate_line_data_proc;

-- Call the procedure
BEGIN
    xxits_ppp_validate_line_data_proc(6939939220, 'dhanush@gmail.com');
END;
