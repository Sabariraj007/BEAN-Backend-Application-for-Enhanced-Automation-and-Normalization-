CREATE OR REPLACE PROCEDURE xxits_ppp_validate_data_proc (
    new_phone IN VARCHAR2,
    new_email IN VARCHAR2
) AS
    duplicate_contact NUMBER := 0;
    duplicate_email NUMBER := 0;
BEGIN
    FOR rec IN (SELECT f.customer_id, f.customer_name, f.contact_number, f.email, f.location, 
                       f.header_id AS header_id_f, g.header_id AS header_id_g 
                FROM xxits_ppp_header_t f, xxits_ppp_line_t g 
                WHERE f.header_id = g.header_id) LOOP

        IF rec.contact_number IS NULL THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Is Invalid.');
        ELSIF rec.contact_number NOT LIKE '9%' AND rec.contact_number NOT LIKE '8%' 
              AND rec.contact_number NOT LIKE '7%' AND rec.contact_number NOT LIKE '6%' THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Should Start With 6, 7, 8, Or 9.');
        ELSIF LENGTH(rec.contact_number) != 10 THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Length Should Be Exactly 10 Digits.');
        ELSE
            SELECT COUNT(*) INTO duplicate_contact
            FROM xxits_ppp_header_t
            WHERE contact_number = rec.contact_number;
            IF duplicate_contact > 1 THEN
                INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
                VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Is Duplicated.');
            END IF;
        END IF;

        IF rec.email IS NULL THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Is Invalid.');
        ELSIF rec.email NOT LIKE '%@gmail.com' THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Must Be In The Format Of @gmail.com.');
        ELSIF INITCAP(rec.email) = rec.email THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Should Not Start With Capital Letters.');
        ELSIF LENGTH(rec.email) >= 30 THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Should Not Exceed 30 Characters.');
        ELSE
            SELECT COUNT(*) INTO duplicate_email
            FROM xxits_ppp_header_t
            WHERE email = rec.email;

            IF duplicate_email > 1 THEN
                INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
                VALUES (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Duplicate Email Found.');
            END IF;
        END IF;
    END LOOP;

    FOR rec_1 IN (SELECT h.customer_id, h.customer_name, h.contact_number, h.email,h.location, i.order_date, i.payment_method, i.payment_status, 
                         h.header_id AS header_id_h, i.header_id AS header_id_i 
                  FROM xxits_ppp_header_t h, xxits_ppp_line_t i 
                  WHERE h.header_id = i.header_id) LOOP

      
        IF rec_1.order_date IS NULL OR NOT regexp_like(TO_CHAR(rec_1.order_date, 'MM-DD-YYYY'), '^\d{2}-\d{2}-\d{4}$') THEN
            INSERT INTO xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec_1.header_id_h, rec_1.customer_id, rec_1.customer_name, rec_1.contact_number, rec_1.email, rec_1.location, 'E', 'Order Date Format Should Be MM-DD-YYYY.');
        END IF;

      
        IF (rec_1.payment_method = 'Cash' AND rec_1.payment_status = 'Unpaid') OR
           (rec_1.payment_method = 'Paytm' AND rec_1.payment_status = 'Unpaid') THEN
            INSERT INTO xxits_ppp_processing_header_t (header_id, customer_id, customer_name, contact_number, email, error_column, location, error_msg)
            VALUES (rec_1.header_id_h, rec_1.customer_id, rec_1.customer_name, rec_1.contact_number, rec_1.email, rec_1.location, 'E', 'Unpaid Payment Detected.');
        ELSE
            INSERT INTO xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec_1.header_id_h, rec_1.customer_id, rec_1.customer_name, rec_1.contact_number, rec_1.email, rec_1.location, 'V', 'Valid');
        END IF;
    END LOOP;
    
     

    FOR rec_3 IN (SELECT * FROM xxits_ppp_rejected_header_t) LOOP
    CASE
        WHEN rec_3.error_msg = 'Phone Number Is Invalid.' THEN
            UPDATE xxits_ppp_header_t
            SET contact_number = new_phone, error_column = 'V', error_msg = 'Valid'
            WHERE header_id = rec_3.header_id;
            INSERT INTO xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec_3.header_id, rec_3.customer_id, rec_3.customer_name, rec_3.contact_number, rec_3.email, rec_3.location, 'V', 'Valid');
        WHEN rec_3.error_msg = 'Email Is Invalid.' THEN
            UPDATE xxits_ppp_header_t
            SET email = new_email, error_column = 'V', error_msg = 'Valid'
            WHERE header_id = rec_3.header_id;
            INSERT INTO xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            VALUES (rec_3.header_id, rec_3.customer_id, rec_3.customer_name, rec_3.contact_number, rec_3.email, rec_3.location, 'V', 'Valid');
        ELSE
            
            NULL; 
    END CASE;

   -- DELETE FROM xxits_ppp_rejected_header_t WHERE header_id = rec_3.header_id;
END LOOP;


    FOR rec_4 IN (SELECT * FROM xxits_ppp_processing_header_t) LOOP
        CASE
            WHEN rec_4.error_msg = 'Unpaid Payment Detected.' THEN
                UPDATE xxits_ppp_line_t
                SET payment_status = 'Paid', error_column = 'V', error_msg = 'Valid'
                WHERE header_id = rec_4.header_id;
                INSERT INTO xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
                VALUES (rec_4.header_id, rec_4.customer_id, rec_4.customer_name, rec_4.contact_number, rec_4.email, rec_4.location, 'V', 'Valid');
        END CASE;

        --DELETE FROM xxits_ppp_processing_header_t WHERE header_id = rec_4.header_id;
    END LOOP;

    
END xxits_ppp_validate_data_proc;


Begin
xxits_ppp_validate_data_proc(6673888772,'bigil@gmail.com');
end;