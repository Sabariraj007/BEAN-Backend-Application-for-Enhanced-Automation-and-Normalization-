create or replace procedure xxits_ppp_validate_data_proc (
    new_phone in varchar2,
    new_email in varchar2
) as
    duplicate_contact number := 0;
    duplicate_email number := 0;
begin
    for rec in (select f.customer_id, f.customer_name, f.contact_number, f.email, f.location, 
                       f.header_id as header_id_f, g.header_id as header_id_g 
                from xxits_ppp_header_t f, xxits_ppp_line_t g 
                where f.header_id = g.header_id) loop

        if rec.contact_number is null then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Is Invalid.');
        elsif rec.contact_number not like '9%' and rec.contact_number not like '8%' 
              and rec.contact_number not like '7%' and rec.contact_number not like '6%' then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Should Start With 6, 7, 8, Or 9.');
        elsif length(rec.contact_number) != 10 then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Length Should Be Exactly 10 Digits.');
        else
            select count(*) into duplicate_contact
            from xxits_ppp_header_t
            where contact_number = rec.contact_number;
            if duplicate_contact > 1 then
                insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
                values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Phone Number Is Duplicated.');
            end if;
        end if;

        if rec.email is null then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Is Invalid.');
        elsif rec.email not like '%@gmail.com' then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Must Be In The Format Of @gmail.com.');
        elsif initcap(rec.email) = rec.email then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Should Not Start With Capital Letters.');
        elsif length(rec.email) >= 30 then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Email Should Not Exceed 30 Characters.');
        else
            select count(*) into duplicate_email
            from xxits_ppp_header_t
            where email = rec.email;

            if duplicate_email > 1 then
                insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
                values (rec.header_id_f, rec.customer_id, rec.customer_name, rec.contact_number, rec.email, rec.location, 'E', 'Duplicate Email Found.');
            end if;
        end if;
    end loop;

    for rec_1 in (select h.customer_id, h.customer_name, h.contact_number, h.email,h.location, i.order_date, i.payment_method, i.payment_status, 
                         h.header_id as header_id_h, i.header_id as header_id_i 
                  from xxits_ppp_header_t h, xxits_ppp_line_t i 
                  where h.header_id = i.header_id) loop

      
        if rec_1.order_date is null or not regexp_like(to_char(rec_1.order_date, 'MM-DD-YYYY'), '^\d{2}-\d{2}-\d{4}$') then
            insert into xxits_ppp_rejected_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec_1.header_id_h, rec_1.customer_id, rec_1.customer_name, rec_1.contact_number, rec_1.email, rec_1.location, 'E', 'Order Date Format Should Be MM-DD-YYYY.');
        end if;

      
        if (rec_1.payment_method = 'Cash' and rec_1.payment_status = 'Unpaid') or
           (rec_1.payment_method = 'Paytm' and rec_1.payment_status = 'Unpaid') then
            insert into xxits_ppp_processing_header_t (header_id, customer_id, customer_name, contact_number, email, error_column, location, error_msg)
            values (rec_1.header_id_h, rec_1.customer_id, rec_1.customer_name, rec_1.contact_number, rec_1.email, rec_1.location, 'E', 'Unpaid Payment Detected.');
        else
            insert into xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec_1.header_id_h, rec_1.customer_id, rec_1.customer_name, rec_1.contact_number, rec_1.email, rec_1.location, 'V', 'Valid');
        end if;
    end loop;
    
     

    for rec_3 in (select * from xxits_ppp_rejected_header_t) loop
    case
        when rec_3.error_msg = 'Phone Number Is Invalid.' then
            update xxits_ppp_header_t
            set contact_number = new_phone, error_column = 'V', error_msg = 'Valid'
            where header_id = rec_3.header_id;
            insert into xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec_3.header_id, rec_3.customer_id, rec_3.customer_name, rec_3.contact_number, rec_3.email, rec_3.location, 'V', 'Valid');
        when rec_3.error_msg = 'Email Is Invalid.' then
            update xxits_ppp_header_t
            set email = new_email, error_column = 'V', error_msg = 'Valid'
            where header_id = rec_3.header_id;
            insert into xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
            values (rec_3.header_id, rec_3.customer_id, rec_3.customer_name, rec_3.contact_number, rec_3.email, rec_3.location, 'V', 'Valid');
        else
            
            null; 
    end case;

   -- DELETE FROM xxits_ppp_rejected_header_t WHERE header_id = rec_3.header_id;
end loop;


    for rec_4 in (select * from xxits_ppp_processing_header_t) loop
        case
            when rec_4.error_msg = 'Unpaid Payment Detected.' then
                update xxits_ppp_line_t
                set payment_status = 'Paid', error_column = 'V', error_msg = 'Valid'
                where header_id = rec_4.header_id;
                insert into xxits_ppp_validated_header_t (header_id, customer_id, customer_name, contact_number, email, location, error_column, error_msg)
                values (rec_4.header_id, rec_4.customer_id, rec_4.customer_name, rec_4.contact_number, rec_4.email, rec_4.location, 'V', 'Valid');
        end case;

        --DELETE FROM xxits_ppp_processing_header_t WHERE header_id = rec_4.header_id;
    end loop;

    
end xxits_ppp_validate_data_proc;


begin
xxits_ppp_validate_data_proc(6673888772,'bigil@gmail.com');
end;