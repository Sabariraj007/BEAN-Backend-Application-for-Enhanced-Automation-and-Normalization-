create or replace procedure XXITS_PPP_UPDATE_HEADER_DATA_PROC as
begin
 
  for REC in (select * from XXITS_PPP_COLUMN_T where TABLE_NAME = 'header') loop
    update XXITS_PPP_HEADER_T 
    set ERROR_COLUMN = 'N', 
        ERROR_MSG = null;
  end loop;
end XXITS_PPP_UPDATE_HEADER_DATA_PROC;
/

begin
XXITS_PPP_UPDATE_HEADER_DATA_PROC();
end;

create or replace procedure XXITS_PPP_UPDATE_LINE_DATA_PROC as
begin
  for REC in (select * from XXITS_PPP_COLUMN_T where TABLE_NAME = 'line') loop
    update XXITS_PPP_LINE_T 
    set ERROR_COLUMN = 'N', 
        ERROR_MSG = null;
  end loop;
end XXITS_PPP_UPDATE_LINE_DATA_PROC;
/

begin
 XXITS_PPP_UPDATE_LINE_DATA_PROC();
end;

