
CREATE TABLE po_headers_all (
    header_id         NUMBER ,
    customer_id       NUMBER,
    customer_name     VARCHAR2(100),
    contact_number    VARCHAR2(15),
    email             VARCHAR2(100),
    loc               VARCHAR2(100)
);

CREATE TABLE po_lines_all (
    line_id             NUMBER ,
    header_id           NUMBER,
    total_amount        NUMBER,
    attribute_catagory  VARCHAR2(50),
    attribute_1         VARCHAR2(50),
    attribute_2         VARCHAR2(50),
    attribute_3         VARCHAR2(50),
    attribute_4         VARCHAR2(50),
    attribute_5         VARCHAR2(50),
    attribute_6         VARCHAR2(50),
    attribute_7         VARCHAR2(50),
    attribute_8         VARCHAR2(50),
    attribute_9         VARCHAR2(50),
    attribute_10        VARCHAR2(50),
    attribute_11        VARCHAR2(50),
    creation_by         VARCHAR2(50),
    created_date        DATE DEFAULT SYSDATE,
    login_date          DATE,
    login_by            VARCHAR2(50),
);






create or replace procedure xxits_process_to_standard_po_tables as
begin
    insert into po_headers_all (header_id, customer_id, customer_name, contact_number, email, loc)
    select h.header_id, h.customer_id, h.customer_name, h.contact_number, h.email, h.location
    from xxits_ppp_validated_header_t h
    where not exists (
        select 1 from po_headers_all ph where ph.header_id = h.header_id
    );

    insert into po_lines_all (
        line_id, header_id, total_amount, attribute_catagory, attribute_1,
        attribute_2, attribute_3, attribute_4, attribute_5, attribute_6,
        attribute_7, attribute_8, attribute_9, attribute_10, attribute_11,
        creation_by, created_date, login_date, login_by
    )
    select
        l.line_id, l.header_id, l.total_amount, l.attribute_category, 
        l.attribute_1, l.attribute_2, l.attribute_3, l.attribute_4, 
        l.attribute_5, l.attribute_6, l.attribute_7, l.attribute_8, 
        l.attribute_9, l.attribute_10, l.attribute_11, 
        l.creation_by, coalesce(l.created_date, sysdate), 
        coalesce(l.login_date, sysdate), l.login_by
    from xxits_ppp_validated_line_t l
    where not exists (
        select 1 from po_lines_all pl where pl.line_id = l.line_id
    );

    commit;
end xxits_process_to_standard_po_tables;


